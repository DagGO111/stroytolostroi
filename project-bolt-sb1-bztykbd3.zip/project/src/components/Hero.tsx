import React from 'react';
import { Zap, Wrench, Hammer, Paintbrush, Car, Home, Laptop, Trees } from 'lucide-react';

const categories = [
  { name: 'Электрика', icon: Zap, color: 'bg-yellow-100 text-yellow-600' },
  { name: 'Сантехника', icon: Wrench, color: 'bg-blue-100 text-blue-600' },
  { name: 'Строительство', icon: Hammer, color: 'bg-orange-100 text-orange-600' },
  { name: 'Ремонт', icon: Paintbrush, color: 'bg-purple-100 text-purple-600' },
  { name: 'Авто услуги', icon: Car, color: 'bg-red-100 text-red-600' },
  { name: 'Дом и сад', icon: Home, color: 'bg-green-100 text-green-600' },
  { name: 'IT услуги', icon: Laptop, color: 'bg-indigo-100 text-indigo-600' },
  { name: 'Ландшафт', icon: Trees, color: 'bg-emerald-100 text-emerald-600' },
];

export default function Hero() {
  return (
    <div className="bg-gradient-to-br from-blue-50 via-white to-purple-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
            Найдите <span className="text-blue-600">проверенного мастера</span>
            <br />
            в вашем городе
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto mb-8">
            Платформа для поиска квалифицированных специалистов с рейтингами и отзывами. 
            Больше никаких звонков по сомнительным объявлениям!
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center max-w-2xl mx-auto mb-12">
            <div className="relative flex-1 w-full">
              <input
                type="text"
                placeholder="Какая услуга вам нужна?"
                className="w-full px-6 py-4 text-lg border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent shadow-sm"
              />
            </div>
            <button className="bg-blue-600 text-white px-8 py-4 text-lg font-semibold rounded-xl hover:bg-blue-700 transition-colors shadow-sm">
              Найти мастера
            </button>
          </div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-4">
          {categories.map((category) => {
            const IconComponent = category.icon;
            return (
              <button
                key={category.name}
                className="flex flex-col items-center p-4 bg-white rounded-xl shadow-sm hover:shadow-md transition-all duration-200 hover:scale-105 group"
              >
                <div className={`p-3 rounded-lg ${category.color} group-hover:scale-110 transition-transform`}>
                  <IconComponent className="h-6 w-6" />
                </div>
                <span className="mt-3 text-sm font-medium text-gray-700 text-center">
                  {category.name}
                </span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}