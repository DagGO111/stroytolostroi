import React from 'react';
import WorkerCard from './WorkerCard';

const workers = [
  {
    id: 1,
    name: 'Александр Петров',
    profession: 'Электрик',
    rating: 4.9,
    reviewCount: 127,
    location: 'Минск, Центр',
    experience: '8 лет',
    hourlyRate: 25,
    avatar: 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=2',
    verified: true,
    responseTime: '2 часа',
    completedJobs: 234
  },
  {
    id: 2,
    name: 'Елена Козлова',
    profession: 'Дизайнер интерьера',
    rating: 4.8,
    reviewCount: 89,
    location: 'Минск, Заводской',
    experience: '5 лет',
    hourlyRate: 30,
    avatar: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=2',
    verified: true,
    responseTime: '1 час',
    completedJobs: 156
  },
  {
    id: 3,
    name: 'Дмитрий Волков',
    profession: 'Сантехник',
    rating: 4.7,
    reviewCount: 203,
    location: 'Минск, Московский',
    experience: '12 лет',
    hourlyRate: 22,
    avatar: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=2',
    verified: true,
    responseTime: '3 часа',
    completedJobs: 445
  },
  {
    id: 4,
    name: 'Анна Сидорова',
    profession: 'Маляр-штукатур',
    rating: 4.9,
    reviewCount: 156,
    location: 'Минск, Ленинский',
    experience: '6 лет',
    hourlyRate: 20,
    avatar: 'https://images.pexels.com/photos/1036623/pexels-photo-1036623.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=2',
    verified: true,
    responseTime: '1 час',
    completedJobs: 298
  },
  {
    id: 5,
    name: 'Михаил Иванов',
    profession: 'Плотник',
    rating: 4.6,
    reviewCount: 74,
    location: 'Минск, Партизанский',
    experience: '10 лет',
    hourlyRate: 28,
    avatar: 'https://images.pexels.com/photos/1681010/pexels-photo-1681010.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=2',
    verified: false,
    responseTime: '4 часа',
    completedJobs: 167
  },
  {
    id: 6,
    name: 'Ольга Романова',
    profession: 'Уборщица',
    rating: 4.8,
    reviewCount: 312,
    location: 'Минск, Октябрьский',
    experience: '4 года',
    hourlyRate: 15,
    avatar: 'https://images.pexels.com/photos/1065084/pexels-photo-1065084.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=2',
    verified: true,
    responseTime: '2 часа',
    completedJobs: 567
  }
];

export default function WorkersList() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h2 className="text-3xl font-bold text-gray-900">Лучшие мастера</h2>
          <p className="text-gray-600 mt-2">Проверенные специалисты с высокими рейтингами</p>
        </div>
        
        <div className="flex items-center space-x-4">
          <select className="border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500">
            <option>Все категории</option>
            <option>Электрика</option>
            <option>Сантехника</option>
            <option>Ремонт</option>
            <option>Уборка</option>
          </select>
          
          <select className="border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500">
            <option>По рейтингу</option>
            <option>По цене</option>
            <option>По отзывам</option>
            <option>По времени ответа</option>
          </select>
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {workers.map((worker) => (
          <WorkerCard key={worker.id} worker={worker} />
        ))}
      </div>
      
      <div className="text-center mt-12">
        <button className="bg-blue-600 text-white px-8 py-3 rounded-lg hover:bg-blue-700 transition-colors font-medium">
          Показать больше мастеров
        </button>
      </div>
    </div>
  );
}