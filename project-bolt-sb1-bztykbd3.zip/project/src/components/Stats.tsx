import React from 'react';
import { Users, CheckCircle, Star, Clock } from 'lucide-react';

const stats = [
  {
    icon: Users,
    value: '5,000+',
    label: 'Проверенных мастеров',
    color: 'text-blue-600'
  },
  {
    icon: CheckCircle,
    value: '25,000+',
    label: 'Выполненных заказов',
    color: 'text-green-600'
  },
  {
    icon: Star,
    value: '4.8',
    label: 'Средний рейтинг',
    color: 'text-yellow-600'
  },
  {
    icon: Clock,
    value: '2 часа',
    label: 'Среднее время ответа',
    color: 'text-purple-600'
  }
];

export default function Stats() {
  return (
    <div className="bg-gray-50 py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">
            Почему выбирают SkillHub?
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Мы объединяем лучших мастеров и клиентов, обеспечивая качество и безопасность каждой сделки
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {stats.map((stat, index) => {
            const IconComponent = stat.icon;
            return (
              <div key={index} className="bg-white rounded-xl p-6 shadow-sm text-center">
                <div className={`inline-flex items-center justify-center w-12 h-12 rounded-lg bg-gray-100 ${stat.color} mb-4`}>
                  <IconComponent className="h-6 w-6" />
                </div>
                <div className="text-3xl font-bold text-gray-900 mb-2">
                  {stat.value}
                </div>
                <div className="text-gray-600">
                  {stat.label}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}