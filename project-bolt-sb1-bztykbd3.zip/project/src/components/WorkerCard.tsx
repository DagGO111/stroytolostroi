import React from 'react';
import { Star, MapPin, Clock, CheckCircle } from 'lucide-react';

interface WorkerCardProps {
  worker: {
    id: number;
    name: string;
    profession: string;
    rating: number;
    reviewCount: number;
    location: string;
    experience: string;
    hourlyRate: number;
    avatar: string;
    verified: boolean;
    responseTime: string;
    completedJobs: number;
  };
}

export default function WorkerCard({ worker }: WorkerCardProps) {
  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star
        key={i}
        className={`h-4 w-4 ${
          i < Math.floor(rating)
            ? 'text-yellow-400 fill-current'
            : i < rating
            ? 'text-yellow-400 fill-current opacity-50'
            : 'text-gray-300'
        }`}
      />
    ));
  };

  return (
    <div className="bg-white rounded-xl shadow-sm hover:shadow-lg transition-all duration-200 p-6 border border-gray-100 hover:border-blue-200 group">
      <div className="flex items-start space-x-4">
        <div className="relative">
          <img
            src={worker.avatar}
            alt={worker.name}
            className="w-16 h-16 rounded-full object-cover"
          />
          {worker.verified && (
            <CheckCircle className="absolute -bottom-1 -right-1 h-5 w-5 text-green-500 bg-white rounded-full" />
          )}
        </div>
        
        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold text-gray-900 group-hover:text-blue-600 transition-colors">
              {worker.name}
            </h3>
            <span className="text-lg font-bold text-blue-600">
              ${worker.hourlyRate}/час
            </span>
          </div>
          
          <p className="text-gray-600 mb-2">{worker.profession}</p>
          
          <div className="flex items-center space-x-1 mb-2">
            <div className="flex items-center space-x-1">
              {renderStars(worker.rating)}
            </div>
            <span className="text-sm font-medium text-gray-900">
              {worker.rating}
            </span>
            <span className="text-sm text-gray-500">
              ({worker.reviewCount} отзывов)
            </span>
          </div>
          
          <div className="flex items-center text-sm text-gray-500 space-x-4 mb-3">
            <div className="flex items-center space-x-1">
              <MapPin className="h-4 w-4" />
              <span>{worker.location}</span>
            </div>
            <div className="flex items-center space-x-1">
              <Clock className="h-4 w-4" />
              <span>Ответ за {worker.responseTime}</span>
            </div>
          </div>
          
          <div className="flex items-center justify-between">
            <div className="text-sm text-gray-600">
              <span className="font-medium">{worker.completedJobs}</span> выполненных работ
            </div>
            <button className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors text-sm font-medium">
              Связаться
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}